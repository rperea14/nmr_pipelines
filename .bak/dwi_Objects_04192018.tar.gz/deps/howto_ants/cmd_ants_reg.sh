antsRegistrationSyN.sh  -d 3 -n 1 -t b -r 4 -p d -m FMRIB58_FA_1mm.nii.gz -f 150226_8CSAD00007_FA.nii.gz -o FMRIB_2_150226_8CSAD00007
