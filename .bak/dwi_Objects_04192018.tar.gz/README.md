# nmr_pipelines
This is the most up-to-date version control of the developed diffusion imaging pipeline.
These set of tools are used for processing imaging data in various NIH projects.
Funded from the following National Institute of Health (NIH) grants: P50-AG005134, R01-AG053509, and P01-AG036694.
 
