#!/bin/bash
while read -r SUBJ ;
do
 pbsubmit -c "sh /eris/bang/ADRC/Scripts/DWI/Compiled_dwi_ADRC/run_dwi_ADRC.sh /usr/pubsw/packages/matlab/R2016a/ $SUBJ " -l nodes=1:ppn=1,vmem=7gb 
done < $1

